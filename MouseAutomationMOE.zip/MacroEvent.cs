namespace MouseAutomation;

public enum MouseActionType
{
    Move,
    LeftDown,
    LeftUp,
    RightDown,
    RightUp,
    MiddleDown,
    MiddleUp,
    Wheel
}

public sealed class MacroEvent
{
    public MouseActionType ActionType { get; init; }

    public int X { get; init; }

    public int Y { get; init; }

    public int WheelDelta { get; init; }

    public long DelayMilliseconds { get; init; }
}