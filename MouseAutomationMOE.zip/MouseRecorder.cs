using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace MouseAutomation;

public sealed class MouseRecorder : IDisposable
{
    private const int WH_MOUSE_LL = 14;

    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_RBUTTONUP = 0x0205;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MBUTTONUP = 0x0208;
    private const int WM_MOUSEWHEEL = 0x020A;

    private readonly object _sync = new();

    private readonly List<MacroEvent> _events = new();

    private LowLevelMouseProc? _hookCallback;

    private IntPtr _hookHandle = IntPtr.Zero;

    private Stopwatch? _stopwatch;

    private long _lastEventTimestamp;

    private bool _recording;

    private int _lastX;

    private int _lastY;

    private bool _hasLastMove;

    public event Action<int, TimeSpan>? RecordingUpdated;

    public bool IsRecording
    {
        get
        {
            lock (_sync)
            {
                return _recording;
            }
        }
    }

    public IReadOnlyList<MacroEvent> Events
    {
        get
        {
            lock (_sync)
            {
                return _events.ToArray();
            }
        }
    }

    public TimeSpan Duration
    {
        get
        {
            lock (_sync)
            {
                return _stopwatch?.Elapsed ?? TimeSpan.Zero;
            }
        }
    }

    public bool Start()
    {
        lock (_sync)
        {
            if (_recording)
                return false;

            _events.Clear();

            _lastX = 0;
            _lastY = 0;
            _hasLastMove = false;

            _stopwatch = Stopwatch.StartNew();
            _lastEventTimestamp = 0;

            _hookCallback = HookCallback;

            _hookHandle = SetWindowsHookEx(
                WH_MOUSE_LL,
                _hookCallback,
                GetModuleHandle(null),
                0);

            if (_hookHandle == IntPtr.Zero)
            {
                _stopwatch.Stop();
                _stopwatch = null;
                _hookCallback = null;
                return false;
            }

            _recording = true;
        }

        RaiseUpdated();

        return true;
    }

    public void Stop()
    {
        lock (_sync)
        {
            if (!_recording)
                return;

            _recording = false;

            if (_hookHandle != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_hookHandle);
                _hookHandle = IntPtr.Zero;
            }

            _stopwatch?.Stop();
        }

        RaiseUpdated();
    }

    private void AddEvent(
        MouseActionType actionType,
        int x,
        int y,
        int wheelDelta = 0)
    {
        int count;
        TimeSpan duration;

        lock (_sync)
        {
            if (!_recording || _stopwatch == null)
                return;

            long timestamp = _stopwatch.ElapsedMilliseconds;

            long delay;

            if (_events.Count == 0)
            {
                delay = 0;
            }
            else
            {
                delay = Math.Max(0, timestamp - _lastEventTimestamp);
            }

            _lastEventTimestamp = timestamp;

            _events.Add(new MacroEvent
            {
                ActionType = actionType,
                X = x,
                Y = y,
                WheelDelta = wheelDelta,
                DelayMilliseconds = delay
            });

            count = _events.Count;
            duration = _stopwatch.Elapsed;
        }

        RecordingUpdated?.Invoke(count, duration);
    }

    private IntPtr HookCallback(
        int nCode,
        IntPtr wParam,
        IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                int message = wParam.ToInt32();

                var data = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);

                switch (message)
                {
                    case WM_MOUSEMOVE:
                    {
                        if (_hasLastMove &&
                            data.pt.X == _lastX &&
                            data.pt.Y == _lastY)
                        {
                            break;
                        }

                        _lastX = data.pt.X;
                        _lastY = data.pt.Y;
                        _hasLastMove = true;

                        AddEvent(
                            MouseActionType.Move,
                            data.pt.X,
                            data.pt.Y);

                        break;
                    }

                    case WM_LBUTTONDOWN:
                        AddEvent(
                            MouseActionType.LeftDown,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_LBUTTONUP:
                        AddEvent(
                            MouseActionType.LeftUp,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_RBUTTONDOWN:
                        AddEvent(
                            MouseActionType.RightDown,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_RBUTTONUP:
                        AddEvent(
                            MouseActionType.RightUp,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_MBUTTONDOWN:
                        AddEvent(
                            MouseActionType.MiddleDown,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_MBUTTONUP:
                        AddEvent(
                            MouseActionType.MiddleUp,
                            data.pt.X,
                            data.pt.Y);
                        break;

                    case WM_MOUSEWHEEL:
                    {
                        short delta = unchecked(
                            (short)((data.mouseData >> 16) & 0xFFFF));

                        AddEvent(
                            MouseActionType.Wheel,
                            data.pt.X,
                            data.pt.Y,
                            delta);

                        break;
                    }
                }
            }
            catch
            {
                // Never allow an exception to escape a native hook callback.
            }
        }

        return CallNextHookEx(
            IntPtr.Zero,
            nCode,
            wParam,
            lParam);
    }

    private void RaiseUpdated()
    {
        int count;
        TimeSpan duration;

        lock (_sync)
        {
            count = _events.Count;
            duration = _stopwatch?.Elapsed ?? TimeSpan.Zero;
        }

        RecordingUpdated?.Invoke(count, duration);
    }

    public void Dispose()
    {
        Stop();
    }

    private delegate IntPtr LowLevelMouseProc(
        int nCode,
        IntPtr wParam,
        IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int X;
        public int Y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MSLLHOOKSTRUCT
    {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport(
        "user32.dll",
        SetLastError = true,
        CharSet = CharSet.Auto)]
    private static extern IntPtr SetWindowsHookEx(
        int idHook,
        LowLevelMouseProc lpfn,
        IntPtr hMod,
        uint dwThreadId);

    [DllImport(
        "user32.dll",
        SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(
        IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(
        IntPtr hhk,
        int nCode,
        IntPtr wParam,
        IntPtr lParam);

    [DllImport(
        "kernel32.dll",
        CharSet = CharSet.Auto,
        SetLastError = true)]
    private static extern IntPtr GetModuleHandle(
        string? lpModuleName);
}