using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Threading;

namespace MouseAutomation;

public partial class MainWindow : Window
{
    private const int WM_HOTKEY = 0x0312;

    private const int HOTKEY_F8 = 1001;
    private const int HOTKEY_F9 = 1002;
    private const int HOTKEY_F10 = 1003;

    private const uint MOD_NOREPEAT = 0x4000;

    private const uint VK_F8 = 0x77;
    private const uint VK_F9 = 0x78;
    private const uint VK_F10 = 0x79;

    private enum AutomationState
    {
        Idle,
        Recording,
        Playing
    }

    private readonly MouseRecorder _recorder;

    private readonly MousePlayer _player;

    private readonly DispatcherTimer _uiTimer;

    private HwndSource? _source;

    private AutomationState _state = AutomationState.Idle;

    private bool _hotkeysRegistered;

    private bool _closing;

    public MainWindow()
    {
        InitializeComponent();

        _recorder = new MouseRecorder();
        _player = new MousePlayer();

        _recorder.RecordingUpdated += Recorder_RecordingUpdated;

        _uiTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(100)
        };

        _uiTimer.Tick += UiTimer_Tick;
        _uiTimer.Start();

        UpdateUi();
    }

    protected override void OnSourceInitialized(
        EventArgs e)
    {
        base.OnSourceInitialized(e);

        _source = (HwndSource)PresentationSource.FromVisual(this)!;

        _source.AddHook(WndProc);

        RegisterGlobalHotkeys();
    }

    private void RegisterGlobalHotkeys()
    {
        if (_source == null)
            return;

        IntPtr handle = _source.Handle;

        bool f8 = RegisterHotKey(
            handle,
            HOTKEY_F8,
            MOD_NOREPEAT,
            VK_F8);

        bool f9 = RegisterHotKey(
            handle,
            HOTKEY_F9,
            MOD_NOREPEAT,
            VK_F9);

        bool f10 = RegisterHotKey(
            handle,
            HOTKEY_F10,
            MOD_NOREPEAT,
            VK_F10);

        if (!f8 || !f9 || !f10)
        {
            if (f8)
                UnregisterHotKey(handle, HOTKEY_F8);

            if (f9)
                UnregisterHotKey(handle, HOTKEY_F9);

            if (f10)
                UnregisterHotKey(handle, HOTKEY_F10);

            MessageBox.Show(
                this,
                "Failed to register one or more global hotkeys.\n\n" +
                "Another application may already be using F8, F9, or F10.",
                "Hotkey Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return;
        }

        _hotkeysRegistered = true;
    }

    private IntPtr WndProc(
        IntPtr hwnd,
        int msg,
        IntPtr wParam,
        IntPtr lParam,
        ref bool handled)
    {
        if (msg == WM_HOTKEY)
        {
            int id = wParam.ToInt32();

            switch (id)
            {
                case HOTKEY_F8:
                    HandleRecordHotkey();
                    handled = true;
                    break;

                case HOTKEY_F9:
                    HandleReplayHotkey();
                    handled = true;
                    break;

                case HOTKEY_F10:
                    HandleEmergencyStopHotkey();
                    handled = true;
                    break;
            }
        }

        return IntPtr.Zero;
    }

    private void HandleRecordHotkey()
    {
        if (_state == AutomationState.Playing)
            return;

        if (_state == AutomationState.Idle)
        {
            StartRecording();
        }
        else if (_state == AutomationState.Recording)
        {
            StopRecording();
        }
    }

    private void HandleReplayHotkey()
    {
        if (_state != AutomationState.Idle)
            return;

        StartReplay();
    }

    private void HandleEmergencyStopHotkey()
    {
        if (_state == AutomationState.Playing)
        {
            StopReplay();
        }
    }

    private void RecordButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        HandleRecordHotkey();
    }

    private void ReplayButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        HandleReplayHotkey();
    }

    private void EmergencyButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        HandleEmergencyStopHotkey();
    }

    private void StartRecording()
    {
        try
        {
            if (!_recorder.Start())
            {
                MessageBox.Show(
                    this,
                    "Unable to install the global mouse hook.",
                    "Recording Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                return;
            }

            _state = AutomationState.Recording;

            UpdateUi();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                $"Unable to start recording:\n\n{ex.Message}",
                "Recording Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void StopRecording()
    {
        try
        {
            _recorder.Stop();

            _state = AutomationState.Idle;

            UpdateUi();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                $"Unable to stop recording:\n\n{ex.Message}",
                "Recording Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void StartReplay()
    {
        var events = _recorder.Events;

        if (events.Count == 0)
        {
            MessageBox.Show(
                this,
                "There is no recorded mouse action to replay.",
                "Nothing to Replay",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        try
        {
            if (!_player.Start(events))
                return;

            _state = AutomationState.Playing;

            UpdateUi();

            _ = MonitorPlaybackAsync();
        }
        catch (Exception ex)
        {
            _state = AutomationState.Idle;

            UpdateUi();

            MessageBox.Show(
                this,
                $"Unable to start playback:\n\n{ex.Message}",
                "Playback Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private async System.Threading.Tasks.Task MonitorPlaybackAsync()
    {
        var task = _player.CurrentTask;

        if (task == null)
            return;

        try
        {
            await task;
        }
        catch (Exception ex)
        {
            if (!_closing)
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    if (_state == AutomationState.Playing)
                    {
                        _state = AutomationState.Idle;
                        UpdateUi();

                        MessageBox.Show(
                            this,
                            $"Playback stopped because of an error:\n\n{ex.Message}",
                            "Playback Error",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);
                    }
                });
            }

            return;
        }

        if (!_closing)
        {
            await Dispatcher.InvokeAsync(() =>
            {
                if (_state == AutomationState.Playing)
                {
                    _state = AutomationState.Idle;
                    UpdateUi();
                }
            });
        }
    }

    private void StopReplay()
    {
        _player.Stop();

        _state = AutomationState.Idle;

        StatusText.Text = "STOPPED";

        UpdateUi();
    }

    private void Recorder_RecordingUpdated(
        int count,
        TimeSpan duration)
    {
        if (_closing)
            return;

        Dispatcher.BeginInvoke(
            DispatcherPriority.Background,
            new Action(() =>
            {
                ActionCountText.Text = count.ToString();
                DurationText.Text =
                    $"{duration.TotalSeconds:F1} seconds";
            }));
    }

    private void UiTimer_Tick(
        object? sender,
        EventArgs e)
    {
        if (_state == AutomationState.Recording)
        {
            TimeSpan duration = _recorder.Duration;

            ActionCountText.Text =
                _recorder.Events.Count.ToString();

            DurationText.Text =
                $"{duration.TotalSeconds:F1} seconds";
        }

        if (_state == AutomationState.Playing &&
            !_player.IsPlaying)
        {
            _state = AutomationState.Idle;
            UpdateUi();
        }
    }

    private void UpdateUi()
    {
        switch (_state)
        {
            case AutomationState.Idle:
                StatusText.Text = "IDLE";
                RecordButton.IsEnabled = true;
                ReplayButton.IsEnabled = true;
                EmergencyButton.IsEnabled = false;
                break;

            case AutomationState.Recording:
                StatusText.Text = "RECORDING";
                RecordButton.IsEnabled = true;
                ReplayButton.IsEnabled = false;
                EmergencyButton.IsEnabled = false;
                break;

            case AutomationState.Playing:
                StatusText.Text = "PLAYING";
                RecordButton.IsEnabled = false;
                ReplayButton.IsEnabled = false;
                EmergencyButton.IsEnabled = true;
                break;
        }

        ActionCountText.Text =
            _recorder.Events.Count.ToString();

        DurationText.Text =
            $"{_recorder.Duration.TotalSeconds:F1} seconds";
    }

    protected override void OnClosed(
        EventArgs e)
    {
        _closing = true;

        _uiTimer.Stop();

        try
        {
            _player.Stop();
        }
        catch
        {
        }

        try
        {
            _recorder.Stop();
        }
        catch
        {
        }

        if (_source != null)
        {
            if (_hotkeysRegistered)
            {
                UnregisterHotKey(
                    _source.Handle,
                    HOTKEY_F8);

                UnregisterHotKey(
                    _source.Handle,
                    HOTKEY_F9);

                UnregisterHotKey(
                    _source.Handle,
                    HOTKEY_F10);

                _hotkeysRegistered = false;
            }

            _source.RemoveHook(WndProc);
        }

        _player.Dispose();
        _recorder.Dispose();

        base.OnClosed(e);
    }

    [DllImport(
        "user32.dll",
        SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RegisterHotKey(
        IntPtr hWnd,
        int id,
        uint fsModifiers,
        uint vk);

    [DllImport(
        "user32.dll",
        SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnregisterHotKey(
        IntPtr hWnd,
        int id);
}