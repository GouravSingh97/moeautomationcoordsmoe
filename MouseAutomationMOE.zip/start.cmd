@echo off
setlocal EnableExtensions

title Mouse Automation Recorder

echo.
echo ==========================================
echo       Mouse Automation Recorder
echo ==========================================
echo.

REM ------------------------------------------------
REM Project directory
REM ------------------------------------------------

cd /d "%~dp0"

echo [1/5] Project:
echo       %CD%
echo.

REM ------------------------------------------------
REM Use local .NET SDK
REM ------------------------------------------------

if not exist "%CD%\.dotnet\dotnet.exe" (
    echo ERROR: Local .NET SDK was not found.
    echo.
    echo Expected:
    echo %CD%\.dotnet\dotnet.exe
    echo.
    echo Install the local .NET SDK first.
    pause
    exit /b 1
)

set "DOTNET_ROOT=%CD%\.dotnet"
set "PATH=%CD%\.dotnet;%PATH%"

REM ------------------------------------------------
REM Disable .NET CLI telemetry for this process
REM ------------------------------------------------

set "DOTNET_CLI_TELEMETRY_OPTOUT=1"

REM ------------------------------------------------
REM Check .NET
REM ------------------------------------------------

echo [2/5] Checking .NET SDK...
dotnet --version

if errorlevel 1 (
    echo.
    echo ERROR: .NET SDK could not be started.
    pause
    exit /b 1
)

echo.

REM ------------------------------------------------
REM Check project
REM ------------------------------------------------

if not exist "%CD%\MouseAutomation.csproj" (
    echo ERROR: MouseAutomation.csproj was not found.
    pause
    exit /b 1
)

echo [3/5] Restoring project...
dotnet restore

if errorlevel 1 (
    echo.
    echo ==========================================
    echo RESTORE FAILED
    echo ==========================================
    pause
    exit /b 1
)

echo.

REM ------------------------------------------------
REM Build
REM ------------------------------------------------

echo [4/5] Building application...
dotnet build --no-restore

if errorlevel 1 (
    echo.
    echo ==========================================
    echo BUILD FAILED
    echo ==========================================
    echo.
    echo The application was NOT started.
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo BUILD SUCCESSFUL
echo ==========================================
echo.

REM ------------------------------------------------
REM Run
REM ------------------------------------------------

echo [5/5] Starting Mouse Automation Recorder...
echo.
echo Hotkeys:
echo.
echo   F8  = Start / Stop Recording
echo   F9  = Continuous Replay
echo   F10 = Emergency Stop
echo.
echo Close the application normally when finished.
echo.

dotnet run --no-build

set "EXITCODE=%ERRORLEVEL%"

echo.
echo ==========================================
echo Application closed.
echo ==========================================
echo.

exit /b %EXITCODE%