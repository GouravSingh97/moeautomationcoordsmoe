using System;
using System.Runtime.InteropServices;
using System.Windows;

namespace MouseAutomation;

public partial class App : Application
{
    private const int DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4;

    [DllImport("user32.dll")]
    private static extern bool SetProcessDpiAwarenessContext(
        IntPtr dpiContext);

    public App()
    {
        try
        {
            SetProcessDpiAwarenessContext(
                new IntPtr(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2));
        }
        catch
        {
            // DPI awareness is best-effort.
        }
    }
}