using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace MouseAutomation;

public sealed class MousePlayer
{
    private const uint INPUT_MOUSE = 0;

    private const uint MOUSEEVENTF_MOVE = 0x0001;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;
    private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
    private const uint MOUSEEVENTF_RIGHTUP = 0x0010;
    private const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
    private const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
    private const uint MOUSEEVENTF_WHEEL = 0x0800;

    private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
    private const uint MOUSEEVENTF_VIRTUALDESK = 0x4000;

    private readonly object _sync = new();

    private CancellationTokenSource? _cancellation;

    private Task? _playbackTask;

    public bool IsPlaying
    {
        get
        {
            lock (_sync)
            {
                return _playbackTask is { IsCompleted: false };
            }
        }
    }

    public Task? CurrentTask
    {
        get
        {
            lock (_sync)
            {
                return _playbackTask;
            }
        }
    }

    public bool Start(IReadOnlyList<MacroEvent> events)
    {
        if (events.Count == 0)
            return false;

        lock (_sync)
        {
            if (_playbackTask is { IsCompleted: false })
                return false;

            _cancellation?.Dispose();

            _cancellation = new CancellationTokenSource();

            CancellationToken token = _cancellation.Token;

            _playbackTask = Task.Run(
                () => PlaybackLoopAsync(events, token),
                token);

            return true;
        }
    }

    public void Stop()
    {
        lock (_sync)
        {
            _cancellation?.Cancel();
        }
    }

    private async Task PlaybackLoopAsync(
        IReadOnlyList<MacroEvent> events,
        CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                foreach (MacroEvent macroEvent in events)
                {
                    await DelayPreciseAsync(
                        macroEvent.DelayMilliseconds,
                        token);

                    token.ThrowIfCancellationRequested();

                    SendMouseEvent(macroEvent);

                    token.ThrowIfCancellationRequested();
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Normal emergency-stop path.
        }
        finally
        {
            lock (_sync)
            {
                if (_playbackTask?.IsCompleted != false)
                {
                    _cancellation?.Dispose();
                    _cancellation = null;
                }
            }
        }
    }

    private static async Task DelayPreciseAsync(
        long milliseconds,
        CancellationToken token)
    {
        if (milliseconds <= 0)
            return;

        if (milliseconds > 10)
        {
            await Task.Delay(
                TimeSpan.FromMilliseconds(milliseconds - 5),
                token);
        }

        if (token.IsCancellationRequested)
            return;

        long remaining = milliseconds;

        if (remaining > 5)
            remaining = 5;

        if (remaining <= 0)
            return;

        var stopwatch = Stopwatch.StartNew();

        while (stopwatch.ElapsedMilliseconds < remaining)
        {
            token.ThrowIfCancellationRequested();

            await Task.Yield();
        }
    }

    private static void SendMouseEvent(MacroEvent macroEvent)
    {
        switch (macroEvent.ActionType)
        {
            case MouseActionType.Move:
                SendMove(
                    macroEvent.X,
                    macroEvent.Y);
                break;

            case MouseActionType.LeftDown:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_LEFTDOWN);
                break;

            case MouseActionType.LeftUp:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_LEFTUP);
                break;

            case MouseActionType.RightDown:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_RIGHTDOWN);
                break;

            case MouseActionType.RightUp:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_RIGHTUP);
                break;

            case MouseActionType.MiddleDown:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_MIDDLEDOWN);
                break;

            case MouseActionType.MiddleUp:
                SendButton(
                    macroEvent.X,
                    macroEvent.Y,
                    MOUSEEVENTF_MIDDLEUP);
                break;

            case MouseActionType.Wheel:
                SendWheel(
                    macroEvent.X,
                    macroEvent.Y,
                    macroEvent.WheelDelta);
                break;
        }
    }

    private static void SendMove(int x, int y)
    {
        GetVirtualScreen(
            out int left,
            out int top,
            out int width,
            out int height);

        int normalizedX = NormalizeCoordinate(
            x,
            left,
            width);

        int normalizedY = NormalizeCoordinate(
            y,
            top,
            height);

        var input = new INPUT
        {
            type = INPUT_MOUSE,
            U = new InputUnion
            {
                mi = new MOUSEINPUT
                {
                    dx = normalizedX,
                    dy = normalizedY,
                    mouseData = 0,
                    dwFlags =
                        MOUSEEVENTF_MOVE |
                        MOUSEEVENTF_ABSOLUTE |
                        MOUSEEVENTF_VIRTUALDESK,
                    time = 0,
                    dwExtraInfo = UIntPtr.Zero
                }
            }
        };

        SendInputChecked(input);
    }

    private static void SendButton(
        int x,
        int y,
        uint buttonFlag)
    {
        GetVirtualScreen(
            out int left,
            out int top,
            out int width,
            out int height);

        int normalizedX = NormalizeCoordinate(
            x,
            left,
            width);

        int normalizedY = NormalizeCoordinate(
            y,
            top,
            height);

        var input = new INPUT
        {
            type = INPUT_MOUSE,
            U = new InputUnion
            {
                mi = new MOUSEINPUT
                {
                    dx = normalizedX,
                    dy = normalizedY,
                    mouseData = 0,
                    dwFlags =
                        MOUSEEVENTF_MOVE |
                        MOUSEEVENTF_ABSOLUTE |
                        MOUSEEVENTF_VIRTUALDESK,
                    time = 0,
                    dwExtraInfo = UIntPtr.Zero
                }
            }
        };

        SendInputChecked(input);

        input.U.mi.dwFlags = buttonFlag;

        SendInputChecked(input);
    }

    private static void SendWheel(
        int x,
        int y,
        int delta)
    {
        GetVirtualScreen(
            out int left,
            out int top,
            out int width,
            out int height);

        int normalizedX = NormalizeCoordinate(
            x,
            left,
            width);

        int normalizedY = NormalizeCoordinate(
            y,
            top,
            height);

        var move = new INPUT
        {
            type = INPUT_MOUSE,
            U = new InputUnion
            {
                mi = new MOUSEINPUT
                {
                    dx = normalizedX,
                    dy = normalizedY,
                    mouseData = 0,
                    dwFlags =
                        MOUSEEVENTF_MOVE |
                        MOUSEEVENTF_ABSOLUTE |
                        MOUSEEVENTF_VIRTUALDESK,
                    time = 0,
                    dwExtraInfo = UIntPtr.Zero
                }
            }
        };

        SendInputChecked(move);

        var wheel = new INPUT
        {
            type = INPUT_MOUSE,
            U = new InputUnion
            {
                mi = new MOUSEINPUT
                {
                    dx = 0,
                    dy = 0,
                    mouseData = unchecked((uint)delta),
                    dwFlags = MOUSEEVENTF_WHEEL,
                    time = 0,
                    dwExtraInfo = UIntPtr.Zero
                }
            }
        };

        SendInputChecked(wheel);
    }

    private static int NormalizeCoordinate(
        int coordinate,
        int origin,
        int size)
    {
        if (size <= 1)
            return 0;

        double normalized =
            (coordinate - origin) * 65535.0 / (size - 1);

        return Math.Clamp(
            (int)Math.Round(normalized),
            0,
            65535);
    }

    private static void GetVirtualScreen(
        out int left,
        out int top,
        out int width,
        out int height)
    {
        left = GetSystemMetrics(SM_XVIRTUALSCREEN);
        top = GetSystemMetrics(SM_YVIRTUALSCREEN);

        width = GetSystemMetrics(SM_CXVIRTUALSCREEN);
        height = GetSystemMetrics(SM_CYVIRTUALSCREEN);

        if (width <= 0)
            width = GetSystemMetrics(SM_CXSCREEN);

        if (height <= 0)
            height = GetSystemMetrics(SM_CYSCREEN);
    }

    private static void SendInputChecked(INPUT input)
    {
        uint result = SendInput(
            1,
            new[] { input },
            Marshal.SizeOf<INPUT>());

        if (result != 1)
        {
            throw new InvalidOperationException(
                "Windows SendInput failed.");
        }
    }

    public void Dispose()
    {
        Stop();
    }

    private const int SM_XVIRTUALSCREEN = 76;
    private const int SM_YVIRTUALSCREEN = 77;
    private const int SM_CXVIRTUALSCREEN = 78;
    private const int SM_CYVIRTUALSCREEN = 79;
    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(
        int nIndex);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(
        uint nInputs,
        INPUT[] pInputs,
        int cbSize);

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)]
        public MOUSEINPUT mi;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }
}